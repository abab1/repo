#include<sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/errno.h>

#ifndef ERESTART
#define ERESTART EINTR
#endif


int main(int argc, char **argv)
{
	struct sockaddr_in serveraddr;
	struct sockaddr_in clientaddr;
	int sock;
	int rqst;
	int errno;

	socklen_t alen;
	

	if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		perror("Cannot create socket");
		return 0;
	}

	printf("create socket: descriptor = %d\n", sock); 

	memset((char*)&serveraddr, 0, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(0);

	if (bind(sock, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0){
		perror("bind failed:\n");
		return 0;
	}

	alen = sizeof(serveraddr);
	if (getsockname(sock, (struct sockaddr *)&serveraddr, &alen) < 0) {
		perror("getsockname failed");
		return 0;
	}

	if(listen(sock, 2) < 0){
		perror("listen failed. \n");
	}

	printf("alen %d\n",alen);
        printf("bind complete, listening on Port number = %d\n", ntohs(serveraddr.sin_port));


	for (;;) {
		while ((rqst = accept(sock, (struct sockaddr *)&clientaddr, &alen)) < 0) {
			/* we may break out of accept if the system call */
                        /* was interrupted. In this case, loop back and */
                        /* try again */
                        if ((errno != ECHILD) && (errno != ERESTART) && (errno != EINTR)) {
                                perror("accept failed");
                                exit(1);
                        } 
                }
		/* the socket for this accepted connection is rqst */
	}	

	exit(0);


}

